#  # # <!-- // /*  SPDX-License-Identifier: blessing */ -->
#  # # <!-- // /*  d a r k s h a p e s */ -->

"""Main Processing Module"""

from typing import Callable
from rich.highlighter import ReprHighlighter
from textual import events, work, on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import TextArea, DataTable
from textual.containers import Container
from textual.reactive import reactive
import tiktoken
from fetch_models import from_ollama_cache  # pylint: disable=import-error
from chat_machine import chat_machine  # pylint: disable=import-error


class Fold(Container):
    """Main interface container"""

    TAG_ACTIVE_HUE: reactive[str] = reactive("orangered")
    TAG_PASSIVE_HUE: reactive[str] = reactive("magenta")
    TEXT = """"""
    BINDINGS = [
        Binding("`", "generate_response", "Send", priority=True),  # Send to LLM
        Binding("escape", "cancel_generation", "Cancel", priority=True),  # Cancel response
    ]
    UNIT1 = "chr /"  # Display Bar Units
    UNIT2 = "tkn /"
    rows: list[tuple] = [
        (0, 0),
        (f"     0{UNIT1}   ", f"0{UNIT2}   "),
    ]
    line_start: reactive[str] = reactive(3, init=True)
    model_cell: reactive[int] = reactive(0.0)
    available_models: reactive[dict] = reactive({})
    current_model: reactive[str] = reactive("")
    hilite = ReprHighlighter()

    def compose(self) -> ComposeResult:
        yield TextArea(self.TEXT, id="message_panel", max_checkpoints=100, theme="vscode_dark", language="python")
        yield DataTable(id="display_bar", show_header=False, show_row_labels=False, cursor_type=None)
        with Container(id="responsive_display"):
            yield TextArea("\n", id="response_panel", language="markdown", read_only=True, soft_wrap=True)
            # yield SpinBox([model for model in from_ollama_cache()], id="tag_line")  # Show system state floating object
            yield DataTable(id="tag_line", show_header=False, cursor_type="cell", classes="tag_line")

    def on_mount(self) -> None:
        """Class method, initialize"""
        self.query_one("#message_panel").border_subtitle = "Prompt"
        display_bar = self.query_one("#display_bar")
        display_bar.add_columns(*self.rows[0])
        display_bar.add_rows(self.rows[1:])
        display_bar.styles.scrollbar_size_horizontal = 0
        tag_line = self.query_one("#tag_line")
        self.available_models = from_ollama_cache()
        tag_line.add_columns(("0", "1"))
        tag_line.add_rows([row.strip()] for row in self.available_models)

    @work(exclusive=True)
    async def _on_key(self, event: events.Key) -> Callable:
        """Class method, window for triggering key bindings"""

        message_panel = self.query_one("#message_panel")
        run_key = hasattr(event, "character") and event.character == "`"
        if run_key or event.key == "grave_accent":
            if message_panel.has_focus:
                message_panel.blur()
            event.prevent_default()
            self.generate_response()

    @work(group="chat")
    async def generate_response(self):
        """Fill display with generated content"""
        message = self.query_one("#message_panel").text
        response_panel = self.query_one("#response_panel")
        response_panel.insert("---\n")
        response_panel.move_cursor(response_panel.document.end)
        response_panel.scroll_end(animate=True)
        self.update_status()
        try:
            async for chunk in chat_machine(self.current_model, message):
                response_panel.insert(chunk)
        except AttributeError as error_log:
            print(error_log)
        self.update_status()

    @on(TextArea.Changed, "#message_panel")
    @work(exclusive=True, group="token")
    async def calculate_tokens(self) -> None:
        """Live display of tokens and characters"""

        message = self.query_one("#message_panel").text
        encoding = tiktoken.get_encoding("cl100k_base")
        token_count = len(encoding.encode(message))
        character_count = len(message)
        display_bar = self.query_one("#display_bar")
        display_bar.update_cell_at((0, 0), f"     {character_count}{self.UNIT1}")
        display_bar.update_cell_at((0, 1), f"{token_count}{self.UNIT2}")

    @work(exclusive=True)
    async def update_status(self) -> None:
        """Provide visual status update of processing"""
        tag_line = self.query_one("#tag_line")
        if "tag_line_active" in tag_line.classes:
            tag_line.set_classes("tag_line")
        else:
            tag_line.set_classes("tag_line_active")

    def _on_mouse_scroll_down(self, event: events.MouseScrollUp) -> None:
        """Determine tag_name focus by negative space, then trigger scroll down at 1/10th intensity"""
        if self.query_one("#responsive_display").has_focus_within != self.query_one("#response_panel").has_focus:
            event.prevent_default()
            if self.model_cell < len(list(self.available_models)) - 1:
                self.model_cell += 0.1
                self.tag_line_scroller()

    def _on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        """Determine tag_name focus by negative space, then trigger scroll down at 1/10th intensity"""
        if self.query_one("#responsive_display").has_focus_within != self.query_one("#response_panel").has_focus:
            event.prevent_default()
            if self.model_cell > 0:
                self.model_cell -= 0.1
                self.tag_line_scroller()

    @work(exclusive=True)
    async def tag_line_scroller(self):
        """Translate scroll events into datatable cursor movement"""
        coordinate = int(round(self.model_cell))
        tag_line = self.query_one("#tag_line")
        tag_line.move_cursor(row=coordinate, column=0)
        key_name = tag_line.get_cell_at((coordinate, 0))
        self.current_model = self.available_models.get(key_name)

    @work(exclusive=True)
    async def cancel_generation(self) -> None:
        """Stop the processing of a model"""
        await self.workers.cancel_group(node="#response_panel", group="chat")
        self.update_status()
